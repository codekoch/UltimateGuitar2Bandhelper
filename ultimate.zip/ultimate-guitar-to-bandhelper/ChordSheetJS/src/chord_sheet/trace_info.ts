interface TraceInfo {
  line?: number | null;
  column?: number | null;
  offset?: number | null;
}

export default TraceInfo;
