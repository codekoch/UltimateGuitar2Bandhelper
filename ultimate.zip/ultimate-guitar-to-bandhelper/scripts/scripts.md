## Package Scripts  

This directory contains some utility scripts to aid in the development, documentation, and maintenance of this package/application.  


| Script Name | Description |
|---|---|
| unpin.js | Remove certificate pinning on the Android application to MiTM requests |  
| logger.js | Log URLs being requested by `okhttp3` + response status codes. unpin.js stopped working, can't be bothered to fix. |  

