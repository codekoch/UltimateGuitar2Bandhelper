# SQLite database stuff (largely useless at first glance)  

The `chords_applicatures` table in `ugpro.db` is probably the only interesting thing from a non-paying-user perspective.

Database location: `/data/data/com.ultimateguitar.tabs/databases`  

Example: `adb pull /data/data/com.ultimateguitar.tabs/databases/ugpro.db`  

Databases/directories within the dir at time of commit:  

- OneSignal.db
- OneSignal.db-journal
- RKStorage
- RKStorage-journal
- androidx.work.workdb
- androidx.work.workdb-shm
- androidx.work.workdb-wal
- com.google.android.datatransport.events
- com.google.android.datatransport.events-journal
- google_app_measurement_local.db
- google_app_measurement_local.db-journal
- ugpro.db
- ugpro.db-journal